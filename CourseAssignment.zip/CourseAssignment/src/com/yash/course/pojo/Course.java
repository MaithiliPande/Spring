package com.yash.course.pojo;

public class Course {
	public int courseId;
	public String courseName;
	public String duration;
	public String type;
	public MainTitle mainTitle;
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public MainTitle getMainTitle() {
		return mainTitle;
	}
	public void setMainTitle(MainTitle mainTitle) {
		this.mainTitle = mainTitle;
	}
	
	
	

}
