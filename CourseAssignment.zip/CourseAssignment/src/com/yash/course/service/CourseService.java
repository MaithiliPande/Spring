package com.yash.course.service;

public interface CourseService {
	public void listCourse();

}
