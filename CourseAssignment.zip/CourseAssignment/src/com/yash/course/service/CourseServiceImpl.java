package com.yash.course.service;

import com.yash.course.pojo.Course;


public class CourseServiceImpl implements CourseService {
	Course course = new Course();
	
	public Course getCourse() {
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}



	@Override
	public void listCourse() {
		System.out.println("----------Courses Available-------");
		System.out.println("Course Id : "+course.getCourseId());
		System.out.println("Course title : "+course.getCourseName());
		System.out.println("Course duration : "+course.getDuration());
		System.out.println("Course type : "+course.getType());
		System.out.println("Main-title Id: "+course.getMainTitle().getTitleId());
		System.out.println("Maint-title Name : "+course.getMainTitle().getTitleName());
		
	}

}
