package com.yash.course.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.course.service.CourseService;

public class StartUp {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		CourseService service = context.getBean("service", CourseService.class);
		service.listCourse();

	}

}
