package com.yash.lifecycle.pojo;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class User implements InitializingBean,DisposableBean{
	public int userId;
	public String userName;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public void showDetails() {
		System.out.println("Id: "+getUserId()+" Name: "+getUserName());
	}
	@Override
	public void destroy() throws Exception {
		System.out.println("DisposableBean destroy method called for user");
		
	}
	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("InitializingBean init method called for user");
		
	}

}
