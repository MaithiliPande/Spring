package com.yash.springjdbcdemo.daoimpl;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.yash.springjdbcdemo.dao.EmployeeDAO;
import com.yash.springjdbcdemo.model.Employee;

@Component
public class EmployeeDAOImpl implements EmployeeDAO {
	
	@Autowired
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	
	public DataSource getDataSource() {
		return dataSource;
	}

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate=new JdbcTemplate(dataSource);
	}

	@Override
	public void saveEmployee(Employee employee) {
		String sql = "INSERT INTO employee(name,contact) VALUES(?,?)";
		
		//Another way to save data in database.
//		Object[] params = new Object[]{employee.getName(), employee.getContact()};
//		jdbcTemplate.update(sql,params);
		
		jdbcTemplate.update(sql,employee.getName(),employee.getContact());
	}
	
	public int getTotalEmployees() {
		return jdbcTemplate.queryForInt("SELECT count(*) FROM employees");
	}
}