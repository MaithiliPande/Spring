package com.yash.springjdbcdemo.dao;

import com.yash.springjdbcdemo.model.Employee;

public interface EmployeeDAO {

	public void saveEmployee(Employee employee);
	public int getTotalEmployees();
}
