package com.yash.cms.daoimpl;

import java.util.ArrayList;
import java.util.List;

import com.yash.cms.dao.UserDAO;
import com.yash.cms.model.User;
/**
 * This userDAOImpl class is an implementation of UserDAO interface. It consist functionality to insert, delete, update and list user.
 * @author maithili.pande
 *
 */
public class UserDAOImpl implements UserDAO {
	/**
	 * Local repository for user.
	 */
	private List<User> userRepository=new ArrayList<User>();
	
	
	/**
	 * this method provides functionality to insert user.
	 * @param user pojo which contains the information about user to be inserted
	 */
	public int insertUser(User user) {
		boolean result=false;
		if(user!=null && !user.getName().equals(null)) {
			result=userRepository.add(user);
		}		
		if(result==true) {
			return 1;
		}else {
			return 0;
		}
	}

	/**
	 * this method deletes a user from repository on the basis of user id passed in the parameter
	 * @param userid is the id of the user to be deleted
	 */
	public int deleteUser(int userid) {
		boolean result=false;
		for (int i=0;i<userRepository.size();i++) {
			{
				if(userRepository.get(i).getId()==userid) {
				userRepository.remove(i);
				result=true;
				}
			}
		}
		if(result==true) {
			return 1;
		}
		else return 0;
	}

	 /**
	  * this method deletes a user from repository on the basis of user pojo in the parameter. 
	  * it indirectly uses delete on basis of userid method 
	  * @param pojo is the object of the user to be deleted
	  */
	public int deleteUser(User user) {
		boolean result = false;
		for(int i=0;i<userRepository.size();i++) {
			if(deleteUser(userRepository.get(i).getId())==1) {
				result = true;
			}
		}
		if(result==true) return 1;
		else return 0;
	}

	/**
	 * this method updates a user in the repository, it checks for the id and updates a user in the repository
	 * @param newuser pojo to be updated in the repository 
	 */
	public int updateUser(User newuser) {
		boolean result=false;
		for(int i=0;i<userRepository.size();i++) {
			if(userRepository.get(i).getId()==newuser.getId()) {
				userRepository.set(i, newuser);
				result=true;
			}
		}
		if (result==true) return 1;
		else return 0;
	}

	/**
	 * this method returns a list of all the users in the repository
	 */
	public List<User> listUser() {
	if(userRepository.isEmpty()) {
		return null;
	}	
	else return userRepository;
	}

}
