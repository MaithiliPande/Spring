package com.yash.cms.dao;

import java.util.List;

import com.yash.cms.model.User;

/**
 * UserDAO will act as a intermediary for managing different user operations in the database like insert,
 * update,delete and list.
 * @author ishan.juneja
 *
 */

public interface UserDAO {

	/**
	 * this method will take a user as an argument and insert it into the database
	 * @param user pojo will contain information about the user to be inserted in the Database.
	 * @return 0 or 1 based on the status for insertion, 0 for not inserted in the database and 1 if insertion is successful
	 */
	public int insertUser(User user);
	/**
	 * this method will delete a user from database on the basis of id
	 * @param userid the id of the user to be deleted from the database
	 */
	public int deleteUser(int userid);
	/**
	 * this method will delete a user from the database on the basis of user pojo passed as an argument
	 * @param user will contain the information about the user to be deleted
	 * @return 0 or 1 based on the status for deletion, 0 for successful deletion in the database and 1 for insertion is successful
	 */
	public int deleteUser(User user);
	/**
	 * this method will update 
	 * @param newuser
	 */
	public int updateUser(User newuser);
	/**
	 * 
	 * @return
	 */
	public List<User> listUser();

}
