package com.yash.cms.model;

/**
 * This User model is an entity. It has details related to the user.
 * 
 * @author maithili.pande
 *
 */
public class User {
	/**
	 * id of the user
	 */
	private int id;
	/**
	 * name of the user
	 */
	private String name;
	/**
	 * contact of user
	 */
	private String contact;
	/**
	 * email of user
	 */
	private String email;
	/**
	 * address of user
	 */
	private String address;
	/**
	 * status of user 
	 */
	private int status;
	/**
	 * role of user
	 */
	private int role;
	/**
	 * username of user
	 */
	private String username;
	/**
	 * password of user
	 */
	private String password;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
  
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getRole() {
		return role;
	}

	public void setRole(int role) {
		this.role = role;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
