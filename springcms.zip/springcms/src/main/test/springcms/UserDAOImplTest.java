package springcms;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.yash.cms.dao.UserDAO;
import com.yash.cms.daoimpl.UserDAOImpl;
import com.yash.cms.model.User;

public class UserDAOImplTest {
	
	private UserDAO userDAO=new UserDAOImpl();
	
	@Test
	public void test_user_insertion_in_userdaoimpl_return_one_if_inserted() {
		User user=new User();
		user.setId(1);
		user.setName("ishan");
		int result=userDAO.insertUser(user);
		assertEquals(1, result);		
	}
	
	@Test(expected=NullPointerException.class)
	public void test_user_insertion_in_userdaoimpl_return_zero_if_user_null() {
		User user = new User();
		userDAO =new UserDAOImpl();
		int actual=userDAO.insertUser(user);
		assertEquals(0, actual);
	}
	
	@Test(expected=NullPointerException.class)
	public void test_user_insertion_in_userdaoimpl_return_zero_if_not_inserted() {

		User user = new User();
		user.setId(1);
		userDAO =new UserDAOImpl();
		int actual=userDAO.insertUser(user);
		assertEquals(0, actual);
	}
	
	@Test
	public void test_user_deletion_with_id_in_userdaoimpl_return_one_if_deleted() {
		User user = new User();
		user.setId(1);
		user.setName("ishan");
		userDAO =new UserDAOImpl();
		userDAO.insertUser(user);
		int actual=userDAO.deleteUser(1);
		assertEquals(1, actual);
	}
	
	@Test
	public void test_user_deletion_with_id_in_userdaoimpl_return_zero_if_not_deleted() {	
		User user = new User();
		user.setId(1);
		user.setName("ishan");
		userDAO =new UserDAOImpl();
		userDAO.insertUser(user);
		int actual=userDAO.deleteUser(30);
		assertEquals(0, actual);
	}
		
	@Test
	public void test_user_deletion_with_id_in_userdaoimpl_return_zero_if_no_data_in_repository() {	
		userDAO =new UserDAOImpl();
		int actual=userDAO.deleteUser(1);
		assertEquals(0, actual);
	}

	@Test
	public void test_user_deletion_with_pojo_in_userdaoimpl_return_zero_if_no_data_in_repository() {	
		userDAO =new UserDAOImpl();
		int actual=userDAO.deleteUser(new User());
		assertEquals(0, actual);
	}
	
	@Test
	public void test_user_deletion_with_pojo_in_userdaoimpl_return_zero_if_not_deleted() {	
		userDAO =new UserDAOImpl();
		int actual=userDAO.deleteUser(new User());
		assertEquals(0, actual);
	}
	
	@Test
	public void test_user_deletion_with_pojo_in_userdaoimpl_return_one_if_deleted() {
		User user = new User();
		user.setId(1);
		user.setName("ishan");
		userDAO =new UserDAOImpl();
		userDAO.insertUser(user);
		User userToBeDeleted=new User();
		userToBeDeleted.setId(1);
		userToBeDeleted.setName("ishan");
		int actual=userDAO.deleteUser(userToBeDeleted);
		assertEquals(1, actual);
	}
	
	@Test
	public void test_user_updation_in_userdaoimpl_return_zero_if_no_data_in_repository() {
		User newuser=new User();
		newuser.setId(1);
		newuser.setName("ishan");
		userDAO =new UserDAOImpl();
		
		int actual=userDAO.updateUser(newuser);
		assertEquals(0, actual);
	}
	
	@Test
	public void test_user_updation_in_userdaoimpl_return_zero_if_not_updated() {
		User olduser = new User();
		olduser.setId(1);
		olduser.setName("ishan");
		User newuser=new User();
		newuser.setId(2);
		newuser.setName("nitesh");
		userDAO =new UserDAOImpl();
		userDAO.insertUser(olduser);
		int actual=userDAO.updateUser(newuser);
		assertEquals(0, actual);
	}
	
	@Test
	public void test_user_updation_in_userdaoimpl_return_one_if_updated() {
		User olduser = new User();
		olduser.setId(1);
		olduser.setName("ishan");
		User newuser=new User();
		newuser.setId(1);
		newuser.setName("nitesh");
		userDAO =new UserDAOImpl();
		userDAO.insertUser(newuser);
		int actual=userDAO.updateUser( newuser);
		assertEquals(1, actual);
	}
	
	@Test
	public void test_user_listUser_in_userdaoimpl_return_zero_if_list_is_empty() {
		List<User> result=userDAO.listUser();
		assertEquals(null,result );
	}
	
	@Test
	public void test_user_listUser_in_userdaoimpl_return_list_if_list_is_not_empty() {
		User user=new User();
		user.setName("ishan");
		user.setId(1);
		userDAO.insertUser(user);
		User user2=new User();
		user2.setId(2);
		user2.setName("aakash");
		userDAO.insertUser(user2);
		List<User> result=userDAO.listUser();
		assertEquals(2,result.size() );
	}
}
