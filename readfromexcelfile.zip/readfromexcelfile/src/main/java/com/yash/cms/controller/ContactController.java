package com.yash.cms.controller;


import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import com.yash.cms.model.Contact;
import com.yash.cms.service.ContactService;
import com.yash.cms.serviceimpl.ContactServiceImpl;
/**
 * This class is a controller. This class will perform operation to read the excel file.
 * @author maithili.pande
 *
 */
@Controller
public class ContactController {
	
	/**
	 * This method is used to read excel file and this creates a list of contacts.
	 * @author maithili.pande
	 */
	@RequestMapping(value="/importFile.ds", method= RequestMethod.POST)
	public void importFile() {
		System.out.println("in controller");
		String xlsFilePath = "D:/files/Contacts.xlsx";
//		ServletContext context = session.getServletContext();
//		String path = context.getRealPath(xlsFilePath);
//		String fileName = file.getOriginalFilename();
//		byte[] bytes = file.getBytes();
//		BufferedOutputStream stream;
//		try {
//			stream = new BufferedOutputStream(new FileOutputStream(  
//			         new File(path + File.separator + fileName)));
//			stream.write(bytes);
//			stream.flush();  
//		    stream.close();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}  
		
		 
		    
		
		
		
		
		FileInputStream excelFile = null;
		List<Contact> contactList = new ArrayList<Contact>();
		Contact contact = null;
		ContactService contactService = new ContactServiceImpl();
		
			try {
				excelFile = new FileInputStream(new File(xlsFilePath));
				Workbook workbook = new XSSFWorkbook(excelFile);
				Iterator<Sheet> sheetIterator = workbook.sheetIterator();
				DataFormatter dataFormatter = new DataFormatter();
				while(sheetIterator.hasNext()) {
					Sheet currentSheet = sheetIterator.next();
					Iterator<Row> rowIterator = currentSheet.iterator();
					while(rowIterator.hasNext()) {
						contact = new Contact();
						Row currentRow = rowIterator.next();
						
						Iterator<Cell> cellIterator = currentRow.iterator();
						String user[] = new String[2];
						int i=0;
						while(cellIterator.hasNext()) {
							Cell currentCell = cellIterator.next();
							String cellValue = dataFormatter.formatCellValue(currentCell);
							user[i]=cellValue;
							i++;
						}
						contact.setName(user[0]);
						contact.setContact(user[1]);
						contactList.add(contact);
					}
				}
				workbook.close();
			} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
				e.printStackTrace();
			}finally {
				try {
					excelFile.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			} 
		for (Contact cont : contactList) {
			System.out.println("["+cont.getName()+" "+cont.getContact()+"]");
		}
			contactService.saveContact(contactList);
	}
	
}
