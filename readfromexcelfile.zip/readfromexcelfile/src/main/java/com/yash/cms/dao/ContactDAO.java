package com.yash.cms.dao;

import java.util.List;

import com.yash.cms.model.Contact;
/**
 * This interface will perform operation to save the list related to contacts in database.
 * @author maithili.pande
 *
 */
public interface ContactDAO {
	
	public void storeContacts(List<Contact> contactList);
}
