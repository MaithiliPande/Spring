package com.yash.cms.service;

import java.util.List;

import com.yash.cms.model.Contact;

public interface ContactService {
	public void saveContact(List<Contact> contactList);
}
