package com.yash.cms.daoimpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.yash.cms.dao.ContactDAO;
import com.yash.cms.model.Contact;
/**
 *This class is implementation of ContactDAO interface.
 * @author maithili.pande
 *
 */
public class ContactDAOImpl implements ContactDAO {

	public void storeContacts(List<Contact> contactList) {
		@SuppressWarnings("deprecation")
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		for (Contact contact : contactList) {
			session.save(contact);
		}
		System.out.println("Contact saved");
		try {
			session.getTransaction().commit();	
		}catch (Exception e) {
			session.close();
		}
		
				
		
	}

}
