package com.yash.cms.serviceimpl;


import java.util.List;

import com.yash.cms.dao.ContactDAO;
import com.yash.cms.daoimpl.ContactDAOImpl;
import com.yash.cms.model.Contact;
import com.yash.cms.service.ContactService;

public class ContactServiceImpl implements ContactService {

	public void saveContact(List<Contact> contactList) {
		ContactDAO contactDAO = new ContactDAOImpl();
		contactDAO.storeContacts(contactList);
	}



	
}
