package com.yash.collection.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.collection.pojo.DBInfo;

public class StartUp {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("resource/beans.xml");
		DBInfo dbInfo = (DBInfo) ctx.getBean("dbInfo");
		System.out.println(dbInfo);

	}

}
