package com.yash.address.pojo;

public class UserDetails {
	public String name;
	public String contact;
	public String email;
	public Address address;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public UserDetails(String name, String contact, String email, Address address) {
		super();
		this.name = name;
		this.contact = contact;
		this.email = email;
		this.address = address;
	}
	public UserDetails() {
	}
	
	

}
