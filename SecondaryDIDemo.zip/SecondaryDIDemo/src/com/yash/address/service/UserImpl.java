package com.yash.address.service;

import com.yash.address.pojo.UserDetails;

public class UserImpl implements User{
	UserDetails userDetails = new UserDetails();
	

	public UserDetails getUserDetails() {
		return userDetails;
	}


	public void setUserDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
	}


	@Override
	public void userDetails() {
		System.out.println("----------User Details-----------");
		System.out.println("User name : "+userDetails.getName());
		System.out.println("User contact : "+userDetails.getContact());
		System.out.println("User email : "+userDetails.getEmail());
		System.out.println("----------User address------------");
		System.out.println("City : "+userDetails.getAddress().getCity());
		System.out.println("State : "+userDetails.getAddress().getState());
		System.out.println("Pincode : "+userDetails.getAddress().getPincode());
	}
	

}
