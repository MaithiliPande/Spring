package com.yash.address.service;

public interface User {
	public void userDetails();
}
