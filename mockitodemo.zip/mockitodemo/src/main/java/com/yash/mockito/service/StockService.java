package com.yash.mockito.service;

import com.yash.mockito.model.Stock;

public interface StockService {
	public double getPrice(Stock stock);
}
