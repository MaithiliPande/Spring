package com.yash.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.annotation.Bean;

@Aspect
public class LoggingAspect {
	/*
	 * Case 1
	 * run loggingAdvice for any of the method of Programmer model
	 */
//	@Pointcut("within(com.yash.model..*)")	// configure pointcut for all the subpackages and for all the classes in model or subpackages. 
//	@Pointcut("within(com.yash.model.Programmer)")// This will configure pointcut for all methods withing Programmer class
//	public void forAllMethodsOfProgrammer() {
//	}
//	@Before("forAllMethodsOfProgrammer()")
//	public void loggingAdvice() {
//		System.out.println("Advice run, Get Method called");
//	}
	
	/*
	 * Case 2
	 * Combinig pointcuts
	 * we can combine two pointcuts for one type of advice
	 */
	
	@Pointcut("within(com.yash.model.Programmer)")
	public void forAllMethodsOfProgrammer() {
	}
	@Pointcut("execution(* get*())")
	public void forAllGetters() {
	}
	@Before("forAllMethodsOfProgrammer() && forAllGetters()")
	public void loggingAdvice() {
		System.out.println("Advice run.Get method called");
	}
	@Before("forAllGetters()")
	public void anotherAdvice() {
		System.out.println("Another advice");
	}
	
}
