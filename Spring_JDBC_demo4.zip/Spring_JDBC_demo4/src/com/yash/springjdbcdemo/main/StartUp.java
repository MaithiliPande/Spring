package com.yash.springjdbcdemo.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.springjdbcdemo.dao.EmployeeDAO;
import com.yash.springjdbcdemo.daoimpl.EmployeeDAOImpl;
import com.yash.springjdbcdemo.model.Employee;

public class StartUp {

	public static void main(String[] args) {
		ApplicationContext context  = new ClassPathXmlApplicationContext("beans.xml");
		EmployeeDAO employeeDAO = context.getBean(EmployeeDAOImpl.class);
		Employee employee = new Employee();
		employee.setId(3);
		employee.setName("Rewati");
		employee.setContact("8866557799");
		employeeDAO.saveEmployee(employee);
	}

}
