package com.yash.springjdbcdemo.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.springjdbcdemo.dao.EmployeeDAO;
import com.yash.springjdbcdemo.model.Employee;

public class StartUpApplication {

	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		EmployeeDAO dao = applicationContext.getBean("employeeDAOImpl", EmployeeDAO.class);
		Employee employee = new Employee();
		employee.setName("Mayank");
		employee.setContact("123");
		dao.saveEmployee(employee);
		System.out.println("DATA INSERTED");
	}
	
}
