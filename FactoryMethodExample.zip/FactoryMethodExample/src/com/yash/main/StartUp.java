package com.yash.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.service.Employee;

public class StartUp {

	public static void main(String[] args) {
		//Read the Configuration file using ApplicationContext
        ApplicationContext applicationContext = 
                new ClassPathXmlApplicationContext("beans.xml");
        
        //Get the Employee(Manager) class instance
        Employee manager = (Employee)applicationContext.getBean("manager");
        System.out.println(manager);

        
        //Get the Employee(SeniorManager) class instance
        Employee seniormanager = (Employee)applicationContext.getBean("seniorManager");
        System.out.println(seniormanager);

    }

	}


