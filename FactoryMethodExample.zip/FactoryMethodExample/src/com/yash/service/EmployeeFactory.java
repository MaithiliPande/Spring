package com.yash.service;

public class EmployeeFactory {
	private EmployeeFactory() {
			System.out.println(" employeeFactory obj created");
	}

		
	public static EmployeeFactory createEmployee()
	{
		System.out.println("createEmployee method called");
		return new EmployeeFactory();
	}
		    
	public Employee getManager()
	{
		System.out.println(".........get manger........");
		        Employee emp = new Employee();
		        emp.setName("Manager JavaInterviewPoint");
		        emp.setAge(45);
		        emp.setDesignation("Manager");
		        System.out.println("manager set hua");
		        return emp;
		    }
		    
		    public Employee getSeniorManager()
		    {
		    	System.out.println(".........get senior manager........");
		        Employee emp = new Employee();
		        emp.setName("SeniorManager JavaInterviewPoint");
		        emp.setAge(50);
		        emp.setDesignation("SeniorManager");
		        System.out.println("senior manager set hua");
		        return emp;
		    }
	

}
