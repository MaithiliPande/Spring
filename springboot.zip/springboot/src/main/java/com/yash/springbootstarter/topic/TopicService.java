package com.yash.springbootstarter.topic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TopicService {
	private List<Topic> topics = new ArrayList<>(Arrays.asList(new Topic(1, "spring", "Spring framework description"),
																new Topic(2, "hibernate", "Hibernate Framework description"),
																new Topic(3, "javascript", "Javascript description")));
	public List<Topic> getAllTopics(){
		return topics;
	}
	
	
	
}
