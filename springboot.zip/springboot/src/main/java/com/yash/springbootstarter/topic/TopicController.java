package com.yash.springbootstarter.topic;

public class TopicController {

}
