package com.yash.inheritance.pojo;

public class Employee {
	public int eid;
	public String ename;
	public String country;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		System.out.println("setting id");
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		System.out.println("setting country");
		this.country = country;
	}
	public String showEmployeeDetails() {
		return ("Id: "+getEid()+" Name: "+getEname()+" Country: "+getCountry());
	}
//	public Employee(int eid, String ename, String country) {
//		System.out.println("Employee object created");
//		this.eid = eid;
//		this.ename = ename;
//		this.country = country;
//	}
	

}
