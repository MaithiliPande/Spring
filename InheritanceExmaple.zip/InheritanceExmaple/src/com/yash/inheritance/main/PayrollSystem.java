package com.yash.inheritance.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.inheritance.pojo.Employee;

public class PayrollSystem {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		Employee emp = context.getBean("empDetail", Employee.class);
		String detail = emp.showEmployeeDetails();
		System.out.println(detail);
		
	}

}
