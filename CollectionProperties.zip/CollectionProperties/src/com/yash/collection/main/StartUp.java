package com.yash.collection.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.collection.pojo.DBInformation;

public class StartUp {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");
		DBInformation dbInfo = (DBInformation) ctx.getBean("dbInfo");
		dbInfo.showDetails();

	}

}
