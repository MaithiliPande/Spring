package com.yash.collection.pojo;

import java.util.Properties;
import java.util.Set;

public class DBInformation {
	private Properties dbInformation;

	
	public Properties getDbInformation() {
		return dbInformation;
	}


	public void setDbInformation(Properties dbInformation) {
		this.dbInformation = dbInformation;
	}


	public  void showDetails() {
		Set<String> dbKeys = dbInformation.stringPropertyNames();
		for (String key : dbKeys) {
			System.out.println(key+"-"+dbInformation.get(key));
		}
	}

}
