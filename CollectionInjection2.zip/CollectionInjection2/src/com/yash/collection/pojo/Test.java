package com.yash.collection.pojo;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
//import java.util.List;
//import java.util.Map;
import java.util.Set;
import java.util.Vector;
@SuppressWarnings("rawtypes")
public class Test {

//	private List trainees;
	private Vector trainees;
//	private Set courses;
	private LinkedHashSet courses;
//	private Map<String, String> traineesMentors;
	private LinkedHashMap<String, String> traineesMentors;
	
	
//	public List getTrainees() {
//		return trainees;
//	}
//	public void setTrainees(List trainees) {
//		this.trainees = trainees;
//	}
//	public Set getCourses() {
//		return courses;
//	}
//	public void setCourses(Set courses) {
//		this.courses = courses;
//	}
//	public Map<String, String> getTraineesMentors() {
//		return traineesMentors;
//	}
//	public void setTraineesMentors(Map<String, String> traineesMentors) {
//		this.traineesMentors = traineesMentors;
//	}
	
	
	public Vector getTrainees() {
		return trainees;
	}

	public void setTrainees(Vector trainees) {
		this.trainees = trainees;
	}

	public LinkedHashSet getCourses() {
		return courses;
	}

	public void setCourses(LinkedHashSet courses) {
		this.courses = courses;
	}

	public LinkedHashMap<String, String> getTraineesMentors() {
		return traineesMentors;
	}

	public void setTraineesMentors(LinkedHashMap<String, String> traineesMentors) {
		this.traineesMentors = traineesMentors;
	}
	
	
	public void showDetails() {
		System.out.println("Trainee List");
		System.out.println("Course List");
		for (Object trainee : trainees) {
			System.out.println(trainee);
		}
		System.out.println("-----------------------");
		System.out.println("Course List");
		for (Object course : courses) {
			System.out.println(course);
		}
		System.out.println("-----------------------");
		System.out.println("Trainee Mentor List");
		Set<String> traineeMentor = traineesMentors.keySet();
		for (String traineeName : traineeMentor) {
			System.out.println(traineeName+"-"+traineeMentor);
			
		}
	}
	
	

	public void getObjectType() {
		System.out.println("Trainee List type -"+trainees.getClass());
		System.out.println("Course Set type -"+courses.getClass());
		System.out.println("TraineesMentor Map type -"+traineesMentors.getClass());
	}

}
