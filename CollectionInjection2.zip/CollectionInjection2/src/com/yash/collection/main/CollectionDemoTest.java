package com.yash.collection.main;



import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.collection.pojo.Test;

public class CollectionDemoTest {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");
		Test test =  (Test)ctx.getBean("test");
		test.showDetails();
		test.getObjectType();
		

	}

}
