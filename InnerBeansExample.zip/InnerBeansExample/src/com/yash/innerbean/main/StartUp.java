package com.yash.innerbean.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.innerbean.pojo.ATM;

public class StartUp {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
//		ATM atm = (ATM) context.getBean("atm");
		ATM atm = (ATM) context.getBean("sbiatm"); //using alias name
		atm.printBalance("ac001115559996478");

	}

}
