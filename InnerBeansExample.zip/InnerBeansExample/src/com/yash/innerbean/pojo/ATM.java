package com.yash.innerbean.pojo;

public class ATM {
	Printer printer = new Printer();

	public Printer getPrinter() {
		return printer;
	}

	public void setPrinter(Printer printer) {
		this.printer = printer;
	}
	
	public void printBalance(String accountNumber) {
		getPrinter().printBalance(accountNumber);
	}

}
