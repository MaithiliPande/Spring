package com.yash.innerbean.pojo;

public class Printer {
	public String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	public void printBalance(String accountNumber) {
		System.out.println(getMessage()+" "+accountNumber);
	}

}
