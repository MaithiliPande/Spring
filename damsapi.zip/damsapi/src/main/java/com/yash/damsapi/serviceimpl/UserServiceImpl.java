package com.yash.damsapi.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.yash.damsapi.dao.UserDAO;
import com.yash.damsapi.daoimpl.UserDAOImpl;
import com.yash.damsapi.model.User;
import com.yash.damsapi.service.UserService;

public class UserServiceImpl implements UserService{
	private static Logger logger= Logger.getLogger(UserServiceImpl.class);
	private UserDAO userDAO=null;
	
	public UserServiceImpl() {
		userDAO= new UserDAOImpl();
		logger.info("user service object created:"+userDAO);
	}
	
	@Override
	public void registerUser(User user) {
		userDAO.insert(user);
		
	}

	@Override
	public User userAuthentication(String username, String password) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<User> listUsers(Integer id) {
		return userDAO.list(id);
	}
	
	@Override
	public void deleteUser(Integer id) {
		userDAO.delete(id);
	}

}
