package com.yash.damsapi.dao;

import java.util.List;

import com.yash.damsapi.model.User;

/**
 * This is an interface. It contains abstract method to save user.
 * @author maithili.pande
 *
 */
public interface UserDAO {
	public void insert(User user);
	public List<User> list(Integer id);
	public void delete(Integer id);
}
