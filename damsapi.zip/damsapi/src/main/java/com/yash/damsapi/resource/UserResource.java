package com.yash.damsapi.resource;


import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.yash.damsapi.model.User;
import com.yash.damsapi.service.UserService;
import com.yash.damsapi.serviceimpl.UserServiceImpl;
@Path("/users")
public class UserResource {
	UserService userService = new UserServiceImpl();
	@POST
	@Path("/add")
	@Consumes(MediaType.APPLICATION_JSON)
	public void addUser(User user) {
		System.out.println("in user resource addUser()");
		userService.registerUser(user);
	}
	@GET
	@Path("/list/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<User> listUser(@PathParam("id")int id){
		return userService.listUsers(id);
	}
	
	@GET
	@Path("/delete/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public void deleteUser(@PathParam("id")int id){
		userService.deleteUser(id);
	}
}
