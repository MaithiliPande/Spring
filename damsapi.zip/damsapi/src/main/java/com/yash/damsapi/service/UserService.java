package com.yash.damsapi.service;

import java.util.List;

import com.yash.damsapi.model.User;

public interface UserService {
	/**
	 * This will register user
	 * @param user
	 */
	public void registerUser(User user);
	/**
	 * This will authenticate the user based on username and password
	 * @param username of user
	 * @param password of user
	 * @return user record if user is authenticated.
	 */
	public User userAuthentication(String username,String password);
	/**
	 * This will list all the users
	 * @return list of users
	 */
	public List<User> listUsers(Integer id);
	
	public void deleteUser(Integer id);
}
