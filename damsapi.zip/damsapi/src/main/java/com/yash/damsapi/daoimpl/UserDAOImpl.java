package com.yash.damsapi.daoimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.yash.damsapi.dao.UserDAO;
import com.yash.damsapi.model.User;
import com.yash.damsapi.util.DBUtil;

/**
 * This is the implementation of UserDAO interface. 
 * @author maithili.pande
 *
 */

public class UserDAOImpl implements UserDAO{
	private static Logger logger= Logger.getLogger(UserDAOImpl.class);
	PreparedStatement pstmt = null;
	@Override
	public void insert(User user){
		String sql="insert into users(firstName,lastName,contact,email,address,loginName,password)"
				+ " values(?,?,?,?,?,?,?)";
		pstmt=DBUtil.createPreparedStatement(sql);
		try {
		pstmt.setString(1, user.getFirstName());
		pstmt.setString(2, user.getLastName());
		pstmt.setString(3, user.getContact());
		pstmt.setString(4, user.getEmail());
		pstmt.setString(5, user.getAddress());
		pstmt.setString(6, user.getLoginName());
		pstmt.setString(7, user.getPassword());
		pstmt.execute();
		logger.info("user inserted successfully..chechkDB");
		}
		catch (SQLException e) {
			logger.error(e);
		}finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				logger.error(e);
			}
		}
		
	}
	@Override
	public List<User> list(Integer id) {
		List<User> users = new ArrayList<>();
		String sql = "select * from users where id="+id;
		pstmt=DBUtil.createPreparedStatement(sql);
		ResultSet rs = null;
		try {
			rs = pstmt.executeQuery();
			while(rs.next())
			{
				User user = new User();
				user.setId(rs.getInt("id"));
				user.setFirstName(rs.getString("firstName"));
				user.setLastName(rs.getString("lastName"));
				user.setContact(rs.getString("contact"));
				user.setEmail(rs.getString("email"));
				user.setAddress(rs.getString("address"));
				user.setLoginName(rs.getString("loginName"));
				user.setPassword(rs.getString("password"));
				users.add(user);
				
			}
		} catch (SQLException e) {
			logger.error(e);
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				logger.error(e);
			}
		}
		return users;
	}
	@Override
	public void delete(Integer id) {
		String sql = "delete from users where id="+id;
		pstmt = DBUtil.createPreparedStatement(sql);
		try {
			pstmt.execute();
		} catch (SQLException e) {
			logger.error(e);
		}
		
	}
	
	

	
}
