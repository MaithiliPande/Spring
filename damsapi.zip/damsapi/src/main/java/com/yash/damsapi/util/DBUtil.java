package com.yash.damsapi.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

public class DBUtil {
	private static Logger logger = Logger.getLogger(DBUtil.class);
	static String driverClassName="com.mysql.jdbc.Driver";
	static String url="jdbc:mysql://localhost:3306/dams";
	static String user="root";
	static String pwd="root";
	static Connection con=null;
	static PreparedStatement pstmt=null;
	//User userDomain=new User();
	static {

		try {
			Class.forName(driverClassName);
		} catch (ClassNotFoundException e) {
			logger.error(e);
		}
	}
	
	/**
	 * This method should return the connection object based on url, username, password
	 * provided to DriverManager.getConnection() method
	 * @return connection object con
	 */
	public static Connection connection() {
		try {
			con=DriverManager.getConnection(url, user, pwd);
			logger.info("con:-"+con);
		} catch (SQLException e) {
			logger.error(e);
		}
		return con;
	}
	
	/**
	 * This method will return the PreparedStatement object based on the sql provided.
	 * This method should have call for connection because when you need transaction 
	 * that time you will require connection object 
	 * @sql is any query
	 * @return PreparedStatement object
	 */
	public static PreparedStatement createPreparedStatement(String sql) {
		connection();
		try {
			pstmt=con.prepareStatement(sql);
			
		} catch (SQLException e) {
			logger.error(e);
		}
		return pstmt;
	}
	
	/**
	 * This method will close connection
	 */
	public static void closeConnection() {
		try {
			con.close();
		} catch (SQLException e) {
			logger.error(e);
		}
	}
	
	/**
	 * This method will close prepared statement
	 */
	public static void closePreparedStatement() {
		try {
			pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
