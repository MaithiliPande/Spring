package com.yash.qa.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;



public class DbUtil {
	private Properties dbProperties;
	private Connection con;
	private String driverC

	public Properties getDbProperties() {
		return dbProperties;
	}

	public void setDbProperties(Properties dbProperties) {
		this.dbProperties = dbProperties;
	}

	public Connection getCon() {
		return con;
	}

	public void setCon(Connection con) {
		this.con = con;
	}

	public  Connection createConnection() {
		try {
			getProperties();
			Class.forName(driverClassName);
			con = DriverManager.getConnection(url, username, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}
	public void getProperties() {
		String driverClassname = dbProperties.getProperty("driverClassName");
		String username = 
	}
	
}
