package com.yash.qa.model;

import java.util.Properties;

public class DbInformation {
	private Properties dbInfo;

	public Properties getDbInfo() {
		return dbInfo;
	}

	public void setDbInfo(Properties dbInfo) {
		this.dbInfo = dbInfo;
	}
}
