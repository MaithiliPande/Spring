package com.yash.qa.daoimpl;

import java.sql.Connection;
import java.sql.SQLException;

import java.sql.PreparedStatement;
import com.yash.qa.dao.UserDAO;
import com.yash.qa.util.DbUtil;

public class UserDAOImpl implements UserDAO {
//	DbUtil dbUtil = new DbUtil();
//	
//	@Override
//	public void insert() {
//		String sql = "insert into users(id,name,email,password,role_id,course_id) values('1','Maithili','maithilipande@gmail.com','123','1','1'))";
//		try {
//			System.out.println(con+"in user dao");
//			PreparedStatement pstmt = con.prepareStatement(sql);
//			pstmt.execute();
//			pstmt.close();
//			con.close();
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		
//	}

}
