package com.yash.qa.dao;

public interface UserDAO {
	public void insert();
}
