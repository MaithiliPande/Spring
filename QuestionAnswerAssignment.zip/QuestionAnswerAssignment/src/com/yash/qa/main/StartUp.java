package com.yash.qa.main;



import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


import com.yash.qa.util.DbUtil;

public class StartUp {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("resources/beans.xml");
		DbUtil dbInfo = (DbUtil) ctx.getBean("dbProperties");
		

	}

}
