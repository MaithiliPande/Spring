package com.yash.collection.pojo;

import java.util.Properties;
import java.util.Set;

public class TraineeInformation {
	private Properties traineeDetailInformation;

	public Properties getTraineeDetailInformation() {
		return traineeDetailInformation;
	}

	public void setTraineeDetailInformation(Properties traineeDetailInformation) {
		this.traineeDetailInformation = traineeDetailInformation;
	}

	public  void showDetails() {
		Set<String> dbKeys = traineeDetailInformation.stringPropertyNames();
		for (String key : dbKeys) {
			System.out.println(key+"-"+traineeDetailInformation.get(key));
		}
	}

}
