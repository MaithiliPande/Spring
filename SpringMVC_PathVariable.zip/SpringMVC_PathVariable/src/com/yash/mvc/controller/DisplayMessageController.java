package com.yash.mvc.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class DisplayMessageController {
	@RequestMapping("/hello/{username}")
	public ModelAndView hello(@PathVariable("username")String username) {
		
		String message = "Hello "+ username;
		Map<String, String> map = new HashMap<>();
		map.put("msg", message);
		
		return new ModelAndView("welcome", map);
	}
	
	@RequestMapping("/hi")
	public ModelAndView hi() {
		String message = "Hi";
		Map<String, String> map = new HashMap<>();
		map.put("msg", message);
		return new ModelAndView("welcome", map);
	}
}
