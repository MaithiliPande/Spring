package com.yash.daoconstructor.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.daoconstructor.service.DBDAO;

public class DriverTest {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		DBDAO con = context.getBean("connection", DBDAO.class);
		con.connect();
	}

}
