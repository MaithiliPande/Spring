package com.yash.daoconstructor.service;

public class DBDAOImpl implements DBDAO {
	
	public String driver;
	public String url;
	public String username;
	public String password;
	
	public String getDriver() {
		
		return driver;
	}

	public void setDriver(String driver) {
		System.out.println("setting driver");
		this.driver = driver;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		System.out.println("setting url");
		this.url = url;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public DBDAOImpl(String driver, String url, String username, String password) {
		System.out.println("In parameterized constructor");
		this.driver = driver;
		this.url = url;
		this.username = username;
		this.password = password;
		
	}
	


	public DBDAOImpl() {
		System.out.println("in default constructor");
	}

	@Override
	public void connect() {
		System.out.println("Driver class name : "+this.getDriver());
		System.out.println("URL : "+this.getUrl());
		System.out.println("Username :"+this.getUsername());
		System.out.println("Password : "+this.getPassword());
		
	}
}
