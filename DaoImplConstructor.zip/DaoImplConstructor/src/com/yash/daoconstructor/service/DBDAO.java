package com.yash.daoconstructor.service;

public interface DBDAO {
	public void connect();

}
