package com.yash.diexample.service;

public interface MessageRenderer {
	public void render();
	public void setMessageProvider(MessageProvider msgProvider);
	public MessageProvider getMessageProvider();

}
