package com.yash.diexample.service;

public class StandardOutMessageRenderer implements MessageRenderer {
	
	private MessageProvider messageProvider = null;
	
	@Override
	public void render() {
		if(messageProvider == null) {
			throw new RuntimeException("No message provider found");
		}
		System.out.println("Message provider -"+messageProvider.getMessage());
		
	}

	@Override
	public void setMessageProvider(MessageProvider msgProvider) {
		this.messageProvider = msgProvider;
	}

	@Override
	public MessageProvider getMessageProvider() {
		return messageProvider;
	}
	

}
