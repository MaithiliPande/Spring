package com.yash.diexample.service;

public interface MessageProvider {
	public String getMessage();

}
