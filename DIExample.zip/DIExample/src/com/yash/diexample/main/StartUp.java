package com.yash.diexample.main;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

import com.yash.diexample.service.HelloWorldMessageProvider;
import com.yash.diexample.service.MessageProvider;
import com.yash.diexample.service.MessageRenderer;
import com.yash.diexample.service.StandardOutMessageRenderer;

public class StartUp {

	public static void main(String[] args) {
//		MessageRenderer renderer = new StandardOutMessageRenderer();
//		MessageProvider provider = new HelloWorldMessageProvider();
//		renderer.setMessageProvider(provider);//DI
//		renderer.render();
		
		BeanFactory factory = new XmlBeanFactory(new FileSystemResource("beans.xml"));
		MessageRenderer mr = (MessageRenderer) factory.getBean("renderer");
		mr.render();
	}

}
