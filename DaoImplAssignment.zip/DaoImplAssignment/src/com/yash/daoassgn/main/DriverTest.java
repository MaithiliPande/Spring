package com.yash.daoassgn.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.daoassgn.service.DBDAO;
import com.yash.daoassgn.service.DBDAOImpl;

public class DriverTest {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		 DBDAO con = context.getBean("connection", DBDAO.class);
		 con.connect();
	}

}
