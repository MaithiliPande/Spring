package com.yash.daoassgn.service;

public interface DBDAO {
	public void connect();
	public void close();
	

}
