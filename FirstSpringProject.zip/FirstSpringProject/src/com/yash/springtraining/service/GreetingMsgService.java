package com.yash.springtraining.service;

public interface GreetingMsgService {
	public String greetUser();
}
