package com.yash.springtraining.service;

public class GreetingMsgServiceImpl implements GreetingMsgService{

	@Override
	public String greetUser() {
		return "good morning";
	}
	

}
