package com.yash.springtraining.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.springtraining.service.GreetingMsgService;

public class StartUp {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		GreetingMsgService service = context.getBean("greetMsg", GreetingMsgService.class);
		System.out.println(service.greetUser());

	}

}
