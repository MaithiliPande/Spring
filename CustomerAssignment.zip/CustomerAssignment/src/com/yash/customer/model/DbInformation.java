package com.yash.customer.model;

import java.util.Properties;
import java.util.Set;

public class DbInformation {
	private Properties dbInfo;

	public Properties getDbInfo() {
		return dbInfo;
	}

	public void setDbInfo(Properties dbInfo) {
		this.dbInfo = dbInfo;
	}

	public void showDetail() {
		Set<String> dbKey = dbInfo.stringPropertyNames();
		for (String key : dbKey) {
			System.out.println(dbInfo.getProperty(key));
		}
		
	}
	
}
