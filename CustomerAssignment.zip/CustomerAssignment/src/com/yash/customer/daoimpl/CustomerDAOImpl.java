package com.yash.customer.daoimpl;

import com.yash.customer.dao.CustomerDAO;

public class CustomerDAOImpl implements CustomerDAO {
	

	@Override
	public void connect() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void list() {
		// TODO Auto-generated method stub
		
	}

	

}
