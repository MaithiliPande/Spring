package com.yash.customer.main;

import java.sql.Connection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.yash.customer.model.DbInformation;
import com.yash.customer.service.CustomerService;
import com.yash.customer.serviceimpl.CustomerServiceImpl;

public class StartUp {

	public static void main(String[] args) {
		CustomerService service = new CustomerServiceImpl();
		ApplicationContext ctx = new ClassPathXmlApplicationContext("resource/beans.xml");
		DbInformation dbInfo = (DbInformation) ctx.getBean("dbInformation");
		String driverClassName = dbInfo.getDbInfo().getProperty("driverClassName");
		String url = dbInfo.getDbInfo().getProperty("url");
		String username = dbInfo.getDbInfo().getProperty("username");
		String password = dbInfo.getDbInfo().getProperty("password");
		Connection con = service.connect(driverClassName,url,username,password);
		System.out.println("connection="+con);
		
	}

}
