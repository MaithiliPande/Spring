package com.yash.customer.service;

import java.sql.Connection;

public interface CustomerService {
	public Connection connect(String driver,String url, String username, String password);
}
