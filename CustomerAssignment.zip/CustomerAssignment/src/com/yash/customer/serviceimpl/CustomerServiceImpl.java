package com.yash.customer.serviceimpl;

import java.sql.Connection;
import java.sql.DriverManager;

import com.yash.customer.service.CustomerService;

public class CustomerServiceImpl implements CustomerService{
	Connection con;

	

	@Override
	public Connection connect(String driver, String url, String username, String password) {
		try {
			Class c = Class.forName(driver);
			con=DriverManager.getConnection(url, username, password) ;
			System.out.println();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}

}
