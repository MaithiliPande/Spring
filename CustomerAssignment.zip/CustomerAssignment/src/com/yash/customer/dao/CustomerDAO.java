package com.yash.customer.dao;

public interface CustomerDAO {
	public void connect();
	public void list();
}
