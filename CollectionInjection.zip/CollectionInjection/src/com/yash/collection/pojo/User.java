package com.yash.collection.pojo;

import java.util.List;

public class User {
	public int userId;
	public String userName;
	public List<Address> addressList;
	public List<Address> getAddressList() {
		return addressList;
	}
	public void setAddressList(List<Address> addressList) {
		this.addressList = addressList;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public void showUserDetail() {
		System.out.println("------User Details------");
		System.out.println("User Id: "+getUserId());
		System.out.println("User Name: "+getUserName());
		System.out.println("User Address: ");
		for (Address address : addressList) {
			System.out.println(address.getHouseNo()+" "+address.getCity()+" "+address.getState()+" "+address.getPincode());
		}
		
	}

}
