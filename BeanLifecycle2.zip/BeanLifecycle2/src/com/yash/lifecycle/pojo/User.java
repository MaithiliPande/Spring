package com.yash.lifecycle.pojo;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class User implements InitializingBean,DisposableBean{
	public int userId;
	public String userName;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public void showDetails() {
		System.out.println("Id: "+getUserId()+" Name: "+getUserName());
	}
	public void myInit() {
		System.out.println("MyInit() method called for user");
	}
	public void cleanUp() {
		System.out.println("cleanUp() method called for user");
	}
	@Override
	public void destroy() throws Exception {
		System.out.println("destroy() method of DisposableBean called for user");
		
	}
	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("afterPropertiesSet() method of InitializingBean called for user");
		
	}

}
