package com.yash.mockito.business;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.yash.mockito.data.TodoService;
import com.yash.mockito.data.TodoServiceStub;

public class TodoBusinessImplStubTest {

	@Test
	public void test_retrieve_todo_related_to_spring_using_a_stub() {
		TodoService todoServiceStub = new TodoServiceStub();
		TodoBusinessImpl todoBusinessImpl = new TodoBusinessImpl(todoServiceStub);
		List<String> filteredTodos = todoBusinessImpl.retrieveTodoRelatedToSpring("dummy");
		assertEquals(2, filteredTodos.size());
	}

}
