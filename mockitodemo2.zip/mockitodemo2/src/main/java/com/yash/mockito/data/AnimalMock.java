package com.yash.mockito.data;

public class AnimalMock {

	public static void main(String[] args) {
		Animal animal = new Animal() {
			
			public void run() {
				
				
			}
			
			public void eat() {
				
				
			}
		};
		System.out.println(animal);

	}

}
