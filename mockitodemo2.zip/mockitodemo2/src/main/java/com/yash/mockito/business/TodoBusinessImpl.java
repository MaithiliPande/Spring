package com.yash.mockito.business;

import java.util.ArrayList;
import java.util.List;

import com.yash.mockito.data.TodoService;

public class TodoBusinessImpl {
	private TodoService todoService;

	public TodoBusinessImpl(TodoService todoService) {
		super();
		this.todoService = todoService;
	}
	 public List<String> retrieveTodoRelatedToSpring(String user){
		 List<String> filterTodo = new ArrayList<String>();
		 List<String>todos = todoService.retrieveTodos(user);
		 for (String todo : todos) {
			if(todo.contains("Spring")) {
				filterTodo.add(todo);
			}
		}
		return filterTodo;
		 
	 }
}
