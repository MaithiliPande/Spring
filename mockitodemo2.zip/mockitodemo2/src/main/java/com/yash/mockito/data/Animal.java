package com.yash.mockito.data;

public interface Animal {
	public void eat();
	public void run();

}
