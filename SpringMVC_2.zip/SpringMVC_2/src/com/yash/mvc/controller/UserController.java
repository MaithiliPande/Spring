package com.yash.mvc.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.yash.mvc.model.User;

public class UserController implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest req, HttpServletResponse res) throws Exception {
		User user = new User();
		user.setName(req.getParameter("name"));
		user.setContact(req.getParameter("contact"));
		user.setEmail(req.getParameter("email"));
		user.setAddress(req.getParameter("address"));
		
		Map<String, User> map = new HashMap<>();
		map.put("user",user);
		
		return new ModelAndView("welcome", map);
	}
}
