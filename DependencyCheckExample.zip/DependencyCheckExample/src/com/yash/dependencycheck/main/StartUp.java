package com.yash.dependencycheck.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.dependencycheck.pojo.Customer;

public class StartUp {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("resource/beans.xml");
		Customer dbInfo = (Customer) ctx.getBean("dbInfo");
		System.out.println(dbInfo);
		

	}

}
