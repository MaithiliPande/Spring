package com.yash.dependencycheck.service;

import com.yash.dependencycheck.pojo.Customer;

public interface Service {
	public void register(Customer customer);

}
