package com.yash.dependencycheck.dao;

import com.yash.dependencycheck.pojo.Customer;

public interface CustomerDAO {
	public void insert(Customer customer);
}
