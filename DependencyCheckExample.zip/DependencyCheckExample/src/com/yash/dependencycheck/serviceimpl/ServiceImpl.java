package com.yash.dependencycheck.serviceimpl;

import com.yash.dependencycheck.dao.CustomerDAO;
import com.yash.dependencycheck.pojo.Customer;
import com.yash.dependencycheck.service.Service;

public class ServiceImpl implements Service{
	CustomerDAO customerDAO;

	@Override
	public void register(Customer customer) {
		customerDAO.insert(customer);
		
	}

}
