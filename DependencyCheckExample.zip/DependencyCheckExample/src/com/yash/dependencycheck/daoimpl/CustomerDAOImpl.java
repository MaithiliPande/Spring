package com.yash.dependencycheck.daoimpl;

import com.yash.dependencycheck.dao.CustomerDAO;
import com.yash.dependencycheck.pojo.Customer;

public class CustomerDAOImpl implements CustomerDAO {
	

	@Override
	public void insert(Customer customer) {
		System.out.println("Name: "+customer.getName());
		System.out.println("Contact: "+customer.getContact());
		
	}

}
