package com.yash.springbootrestdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootrestdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootrestdemoApplication.class, args);
	}
}
