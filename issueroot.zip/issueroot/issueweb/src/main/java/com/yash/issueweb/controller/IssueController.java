package com.yash.issueweb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.yash.issuecore.domain.Issue;
import com.yash.issuecore.service.IssueService;

@RestController
public class IssueController {
	@Autowired
	private IssueService issueService;
	@RequestMapping(value="/issues",method=RequestMethod.POST)
	public boolean addIssue(@RequestBody Issue issue) {
		return issueService.insertIssue(issue);
	}

}
