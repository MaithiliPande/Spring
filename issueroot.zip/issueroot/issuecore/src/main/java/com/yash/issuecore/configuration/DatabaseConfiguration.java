package com.yash.issuecore.configuration;


import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
@PropertySource("classpath:jdbc.properties")
@ComponentScan("com.yash")
public class DatabaseConfiguration {

	@Autowired
	private Environment environment;
	
	
	
	@Bean
	public DataSource dataSource() {
		DriverManagerDataSource basicDataSource=new DriverManagerDataSource();
		basicDataSource.setDriverClassName(environment.getProperty("driverClassName"));
		basicDataSource.setUrl(environment.getProperty("url"));
		basicDataSource.setUsername(environment.getProperty("jdbc.user"));
		basicDataSource.setPassword(environment.getProperty("jdbc.password"));
		return basicDataSource;
	}
}
