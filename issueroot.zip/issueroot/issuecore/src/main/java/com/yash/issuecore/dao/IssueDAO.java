package com.yash.issuecore.dao;

import com.yash.issuecore.domain.Issue;

public interface IssueDAO {
	public boolean insert(Issue issue);
}
