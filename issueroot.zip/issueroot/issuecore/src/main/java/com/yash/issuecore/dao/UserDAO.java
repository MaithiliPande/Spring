package com.yash.issuecore.dao;

import java.util.List;

import com.yash.issuecore.domain.User;

public interface UserDAO {
	public boolean insert(User user);
	public List<User> list();
	
}
