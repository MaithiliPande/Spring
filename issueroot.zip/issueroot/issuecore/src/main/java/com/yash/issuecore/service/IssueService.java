package com.yash.issuecore.service;

import com.yash.issuecore.domain.Issue;

public interface IssueService {
	public boolean insertIssue(Issue issue);
}
