package com.yash.issuecore.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.issuecore.dao.UserDAO;
import com.yash.issuecore.domain.User;
import com.yash.issuecore.service.UserService;
@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserDAO userDAO;
	public boolean userRegister(User user) {
		return userDAO.insert(user);
	}
	

}
