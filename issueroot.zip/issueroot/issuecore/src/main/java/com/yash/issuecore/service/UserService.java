package com.yash.issuecore.service;

import com.yash.issuecore.domain.User;

public interface UserService {
	public boolean userRegister(User user);
}
