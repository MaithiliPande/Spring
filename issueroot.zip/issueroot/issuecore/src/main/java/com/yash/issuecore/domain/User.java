package com.yash.issuecore.domain;
/**
 * This class acts as a data traveler. It contains data related to user. 
 * Id of user, firstName, lastName, email,, role, status, his loginName and password
 * @author maithili.pande
 *
 */
public class User {
	/**
	 * Id of user
	 */
	private Integer id;
	/**
	 * First Name of user
	 */
	private String firstName;
	/**
	 * Last Name of user
	 */
	private String lastName;
	/**
	 * Email of user
	 */
	private String email;
	/**
	 * Role of user
	 */
	private Integer roleId;
	/**
	 * Status of user
	 */
	private Integer statusId;
	/**
	 * Login name of user
	 */
	private String loginName;
	/**
	 * Passowrd of user
	 */
	private String password;
	
	
	public User() {
		super();
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Integer getRoleId() {
		return roleId;
	}
	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}
	public Integer getStatusId() {
		return statusId;
	}
	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	

}
