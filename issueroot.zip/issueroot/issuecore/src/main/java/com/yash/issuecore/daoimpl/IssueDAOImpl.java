package com.yash.issuecore.daoimpl;


import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.yash.issuecore.dao.IssueDAO;
import com.yash.issuecore.domain.Issue;
@Repository
public class IssueDAOImpl implements IssueDAO{
	@Autowired
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	
	public DataSource getDataSource() {
		return dataSource;
	}

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public boolean insert(Issue issue) {
		String sql = "insert into issues(issue,issueType,userId,issueDescription,createdDate,statusId) value(?,?,?,?,?,?)";
		Object []params = new Object[] {
			issue.getIssue(),
			issue.getIssueType(),
			issue.getUserId(),
			issue.getIssueDescription(),
			issue.getCreatedDate(),
			issue.getStatusId()
		};
		jdbcTemplate.update(sql, params);
		return true;
	}

}
