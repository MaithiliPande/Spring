package com.yash.hello.pojo;

import com.yash.greeting.GreetingService;

public class MorningGreeting implements GreetingService{
	public String message;
	
	
	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}


	@Override
	public void greet(String user) {
		
		System.out.println("Hi"+user+" -"+this.getMessage());
		
		
	}

}
