package com.yash.hello.main;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.hello.pojo.EveningGreeting;
import com.yash.hello.pojo.MorningGreeting;

public class StatupApplication {

	public static void main(String[] args) {
		
		ApplicationContext ctx= new ClassPathXmlApplicationContext("beans.xml");
		MorningGreeting morning = ctx.getBean("morning", MorningGreeting.class);
		EveningGreeting evening = ctx.getBean("evening", EveningGreeting.class);
		morning.greet("Ayushi");
		evening.greet("Chetan");
	}

}
