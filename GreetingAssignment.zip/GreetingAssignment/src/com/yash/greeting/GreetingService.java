package com.yash.greeting;

public interface GreetingService {
	public void greet(String user);
}
