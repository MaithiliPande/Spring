package com.yash.springjdbcdemo.daoimpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import org.springframework.stereotype.Component;

import com.yash.springjdbcdemo.dao.EmployeeDAO;
import com.yash.springjdbcdemo.model.Employee;
@Component
public class EmployeeDAOImpl implements EmployeeDAO{

	String driverClassName="com.mysql.jdbc.Driver";
	String url="jdbc:mysql://localhost/springjdbcdb";
	String user="root";
	String pwd="root";
	Connection con =null;
	PreparedStatement pstmt= null;
	
	public EmployeeDAOImpl() {
		try {
			Class.forName(driverClassName);
			con=DriverManager.getConnection(url, user, pwd); 
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}


	@Override
	public void saveEmployee(Employee employee) {
		
		try {
			String sql="insert into employee(name,contact) values(?,?)";
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, employee.getName());
			pstmt.setString(2, employee.getContact());
			pstmt.execute();
			System.out.println("record has been inserted successfully..checkDB");
			pstmt.close();
			con.close();
		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
