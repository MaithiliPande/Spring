package com.yash.mvc.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/trainer")
public class TrainerController {
	
	@RequestMapping("/trainerWork1.ds")
	public ModelAndView addProject() {
		Map<String, String> map = new HashMap<>();
		map.put("msg", "Trainer work 1 done");
		return new ModelAndView("welcome", map);
	}
	
	@RequestMapping("/trainerWork2.ds")
	public ModelAndView listProject() {
		Map<String, String> map = new HashMap<>();
		map.put("msg", "Trainer work 2 done");
		return new ModelAndView("welcome", map);
	}
	
	@RequestMapping("/trainerWork3.ds")
	public ModelAndView editProject() {
		Map<String, String> map = new HashMap<>();
		map.put("msg", "Trainer work 3 done");
		return new ModelAndView("welcome", map);
	}
}
