package com.yash.mvc.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/admin")
public class AdminController {
	
	@RequestMapping("/addProject.ds")
	public ModelAndView addProject() {
		Map<String, String> map = new HashMap<>();
		map.put("msg", "Project added succecfully");
		
		return new ModelAndView("welcome", map);
	}
	
	@RequestMapping("/listProject.ds")
	public ModelAndView listProject() {
		Map<String, String> map = new HashMap<>();
		map.put("msg", "Project listed succecfully");
		
		return new ModelAndView("welcome", map);
	}
	
	@RequestMapping("/editProject.ds")
	public ModelAndView editProject() {
		Map<String, String> map = new HashMap<>();
		map.put("msg", "Project edited succecfully");
		
		return new ModelAndView("welcome", map);
	}
	
}
