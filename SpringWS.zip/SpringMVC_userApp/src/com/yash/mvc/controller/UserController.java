package com.yash.mvc.controller;

import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.yash.mvc.model.User;

@Controller
@RequestMapping("/users")
public class UserController {
	
	@RequestMapping(value="/showForm",method=RequestMethod.GET)
	public String showRegistraionForm() {
		return "showRegistrationForm";
	}

	@RequestMapping(value="/processUserRegistration", method=RequestMethod.POST)
	public ModelAndView processUserRegstration(@RequestParam String name, @RequestParam String contact,
			@RequestParam String email, @RequestParam String address) {
		User user = new User();
		user.setName(name);
		user.setContact(contact);
		user.setEmail(email);
		user.setAddress(address);
		
		Map<String, User> map = new HashMap<>();
		map.put("user",user);
		
		return new ModelAndView("welcome", map);
	}
}
