package com.yash.damsapp.dao;

import com.yash.damsapp.domain.Schedule;
import com.yash.damsapp.domain.User;

public interface UserDAO {

	public boolean insert(User user);
	public void scheduleapp(Schedule schedule);
}
