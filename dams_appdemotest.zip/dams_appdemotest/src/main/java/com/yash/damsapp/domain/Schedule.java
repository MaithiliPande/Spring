package com.yash.damsapp.domain;

import java.sql.Timestamp;
import java.util.Date;

public class Schedule {

	/**
	 * id of the doctor who is providing the schedule
	 */
	private int userid;
	/**
	 * date for which schedule is being created
	 */
	private Date dateofapp;
	/**
	 * start time of the appointments
	 */
	private String starttime;
	/**
	 * end time of the appointments
	 */
	private String endtime;
	/**
	 * status will show the status of appointment
	 * @return
	 */
	private Integer status;
	public Integer getStatus() {
		return status;
	}
	public void setStatus(int i) {
		this.status = i;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public Date getDateofapp() {
		return dateofapp;
	}
	public void setDateofapp(Date dateofapp) {
		this.dateofapp = dateofapp;
	}
	public String getStarttime() {
		return starttime;
	}
	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}
	public String getEndtime() {
		return endtime;
	}
	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}
	
}
