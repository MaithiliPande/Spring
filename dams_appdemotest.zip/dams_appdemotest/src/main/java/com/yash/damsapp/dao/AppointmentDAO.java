package com.yash.damsapp.dao;

import java.util.Date;
import java.util.List;

import com.yash.damsapp.domain.Appointment;
import com.yash.damsapp.domain.Schedule;


public interface AppointmentDAO {

	public List<Schedule> getAppointments(String date);
	/**
	 * in the patient appointment will be inserted in the database according to the scheduled timing of the doctor
	 * for this i think i need to create a table from where the value will come in the database where we call
	 * call for the appointment 
	 * for ex selecting date and time and details for the appointment 
	 * and after this it should dynamically appointment should be updated and status should shown as booked and that time should not
	 * be shown for the other appointments.
	 * @param appointment
	 * @return
	 */
	public boolean insert(Appointment appointment);

	/**
	 * this method will return the list of the all the appointment booked by the particuler user by using userid 
	 * maybe when doctor is logging in the is should display all the appointmnet to the doctor
	 * it means we have only single doctor in our application and he can see all the appointments
	 * @return list of appointment of only single patient
	 */
	public List<Appointment> list(int userid);
	
	/**
	 * this method will display all the appointment to the doctor
	 * @return list of all appointment
	 */
	public List<Appointment> listAllAppointments();

	/**
	 * this method will cancel the appointment 
	 * -if user cancels the appointment then his appointment will be fully deleted from the database and his time will be ready
	 * other one allocation of then time which is for booking
	 * @param userid
	 * @return 
	 */
	public boolean cancel(int id);
	
	public void delete(Integer id);

}
