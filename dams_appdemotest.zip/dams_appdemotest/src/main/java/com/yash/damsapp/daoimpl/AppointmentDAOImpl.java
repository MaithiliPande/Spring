package com.yash.damsapp.daoimpl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.yash.damsapp.dao.AppointmentDAO;
import com.yash.damsapp.domain.Appointment;
import com.yash.damsapp.domain.Schedule;
import com.yash.damsapp.rowmapper.AppointmentMapper;

@Repository
public class AppointmentDAOImpl implements AppointmentDAO {
	
	private DataSource datasource;
	private JdbcTemplate jdbcTemplate;
	public DataSource getDatasource() {
		return datasource;
	}

	@Autowired
	public void setDatasource(DataSource datasource) {
		this.jdbcTemplate = new JdbcTemplate(datasource);
	}

	public boolean insert(Appointment appointment) {
		
		String sql="insert into appointments(userid,date_created,start_time"
		+" ,end_time_expected"
	+ ") values(?,?,?,?)";
		Object[] params=new Object[]{ appointment.getId(),appointment.getDate_created(),appointment.getStart_time(),
		appointment.getEnd_time_expected()};
		int i=jdbcTemplate.update(sql,params);
		if(i==1){
		String sql1="update schedule set status=2 where date=? and start_time=?";
		jdbcTemplate.update(sql1,appointment.getDate_created(),appointment.getStart_time());
		}
		return true;
	}

	public List<Appointment> list(int userid) {
		return null;
	}

	public List<Appointment> listAllAppointments() {
		String sql="select * from appointments";
		List<Appointment> appointments=jdbcTemplate.query(sql,new AppointmentMapper());
		return appointments;
	}

	public boolean cancel(int id) {
		String updatesql="update appointments set cancel=2 where id=?";
		jdbcTemplate.update(updatesql,id);
		String appointmentsql="select * from appointments where id=?";
		Appointment appointment=jdbcTemplate.queryForObject(appointmentsql,new AppointmentMapper(),id);
		String updatessql="update schedule set status=1 where date=? and start_time=?";
		jdbcTemplate.update(updatessql,appointment.getDate_created(),appointment.getStart_time());
		return false;
	
	}

	public List<Schedule> getAppointments(String date) {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		Date dateparsed = null ;
		try {
			dateparsed=sdf.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		String sql="select * from schedule where date=? and status=1";
		List<Schedule> appointments=jdbcTemplate.query(sql, new RowMapper<Schedule>() {
				public Schedule mapRow(ResultSet rs, int rowNum) throws SQLException {
					Schedule schedule=new Schedule();
					schedule.setUserid(rs.getInt("id"));
					schedule.setDateofapp(rs.getDate("Date"));
					schedule.setStarttime(rs.getString("start_time"));
					schedule.setStatus(rs.getInt("status"));
					return schedule;
			}
		},new Object[]{dateparsed} );
		System.out.println(date);
		return appointments;
		
		
	}

	public void delete(Integer id) {
	cancel(id);
	String sql="delete from appointments where id=?";
	jdbcTemplate.update(sql,id);
	}

}
