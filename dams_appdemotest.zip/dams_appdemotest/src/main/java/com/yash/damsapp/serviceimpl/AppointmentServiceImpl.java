package com.yash.damsapp.serviceimpl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.damsapp.dao.AppointmentDAO;
import com.yash.damsapp.domain.Appointment;
import com.yash.damsapp.domain.Schedule;
import com.yash.damsapp.service.AppointmentService;

@Service
public class AppointmentServiceImpl implements AppointmentService{

@Autowired
AppointmentDAO appointmentDAO;
	
	public List<Schedule> getAppointments(String date) {
		
	List<Schedule> appointments=appointmentDAO.getAppointments(date);
		return appointments;
	}

	public void bookAppointment(Appointment appointment) {
	appointmentDAO.insert(appointment);
		
	}

	public List<Appointment> listappoint() {
		List<Appointment> appointments=appointmentDAO.listAllAppointments();
		return appointments;
	}

	public void cancelAppointment(Integer id) {
	appointmentDAO.cancel(id);	
	}

	public void deleteAppointment(Integer id) {
		appointmentDAO.delete(id);
	}

}
