package com.yash.damsapp.serviceimpl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.yash.damsapp.dao.UserDAO;
import com.yash.damsapp.domain.Schedule;
import com.yash.damsapp.domain.User;
import com.yash.damsapp.service.UserService;
@Service
public class UserServiceImpl  implements UserService{
	
	@Autowired
	private UserDAO userDao;
	@Autowired
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	
	public DataSource getDataSource() {
		return dataSource;
	}
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate=new JdbcTemplate(dataSource);
	}

	public boolean userRegister(User user) {
		boolean userStatus= userDao.insert(user);
		if(userStatus){
			return true;
		}
		else{
			return false;
		}
	}
	public User checkUserLogin(String loginname, String password, String email) {
	
		String sql="select * from users where loginname=? AND password=?";
		User user=null;
		try{
		user=jdbcTemplate.queryForObject(sql, new Object[]{loginname,password},new BeanPropertyRowMapper<User>(User.class));
		System.out.println(user.getLoginname()+user.getPassword());
		return user;
		}catch (Exception e) {
			e.printStackTrace();
			return user;
		}
//		List<User> users=jdbcTemplate.query(sql, new RowMapper<User>() {
//			public User mapRow(ResultSet rs, int rownumber) throws SQLException {
//				User user=new User();
//				user.setLoginname(rs.getString("loginname"));
//				user.setPassword(rs.getString("password"));
//				user.setEmail(rs.getString("email"));
//				return user;
//			}
//		} );
//		
//		
//		if(!users.isEmpty()){
//			System.out.println(users.get(0).getLoginname());
//			return users.get(0);
//		}
//		else{
//			System.out.println("LOGIN FAILED");
//		return null;
//	}
	}
	public void scheduleApp(Schedule schedule) {
	
		userDao.scheduleapp(schedule);
		
	}

}
