package readexcelfile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {
	public static final String xlsFilePath = "D:/files/Contacts.xlsx";
	public static void main(String[] args) {
		try {
			FileInputStream excelFile = new FileInputStream(new File(xlsFilePath));
			Workbook workbook = new XSSFWorkbook(excelFile);
			Iterator<Sheet> sheetIterator = workbook.sheetIterator();
			DataFormatter dataFormatter = new DataFormatter();
			while(sheetIterator.hasNext()) {
				Sheet currentSheet = sheetIterator.next();
				Iterator<Row> rowIterator = currentSheet.iterator();
				while(rowIterator.hasNext()) {
					Row currentRow = rowIterator.next();
					Iterator<Cell> cellIterator = currentRow.iterator();
					while(cellIterator.hasNext()) {
						Cell currentCell = cellIterator.next();
						String cellValue = dataFormatter.formatCellValue(currentCell);
						System.out.println(cellValue);
					}
				}
			}
			workbook.close();
		} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		catch (IOException e) {
			e.printStackTrace();
		}
		
			
			
			
		
	}

}
