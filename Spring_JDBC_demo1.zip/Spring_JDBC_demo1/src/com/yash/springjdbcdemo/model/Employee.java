package com.yash.springjdbcdemo.model;
/**
 * This is a model class. It contains employee's id, name and salary. It acts as a data traveler.
 * @author maithili.pande
 *
 */
public class Employee {
	/**
	 * id of employee
	 */
	private Integer id;
	/**
	 * name of employee
	 */
	private String name;
	/**
	 * salary of employee
	 */
	private String contact;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	
	
}
