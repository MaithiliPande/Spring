package com.yash.springjdbcdemo.main;

import com.yash.springjdbcdemo.dao.EmployeeDAO;
import com.yash.springjdbcdemo.daoimpl.EmployeeDAOImpl;
import com.yash.springjdbcdemo.model.Employee;

public class StartUp {

	public static void main(String[] args) {
		EmployeeDAO employeeDAO = new EmployeeDAOImpl();
		Employee employee = new Employee();
		employee.setName("Rupal");
		employee.setContact("7845956215");
		System.out.println(employee.getName());
		System.out.println(employee.getContact());
		employeeDAO.saveEmployee(employee);
	}

}
