package com.yash.springjdbcdemo.dao;

import com.yash.springjdbcdemo.model.Employee;
/**
 * This is an interface. It contains method to save the employee.
 * @author maithili.pande
 *
 */
public interface EmployeeDAO {
	public void saveEmployee(Employee employee);
}
