package com.yash.beanscope.service;

public interface EmployeeServiceInterface {
	public void setMessage(String message);
	public String getMessage();

}
