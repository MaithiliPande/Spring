package com.yash.beanscope.service;

public class EmployeeServiceImpl implements EmployeeServiceInterface {
	public String message;
	@Override
	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String getMessage() {
		return message;
	}

}
