package com.yash.beanscope.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.beanscope.service.EmployeeServiceInterface;

public class PayrollSystem {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		EmployeeServiceInterface service1 = context.getBean("empService", EmployeeServiceInterface.class);
		service1.setMessage("Service message from A");
		System.out.println("employee service A: "+service1.getMessage());
		EmployeeServiceInterface service2 = context.getBean("empService", EmployeeServiceInterface.class);
		service2.setMessage("Service message from B");
		System.out.println("employee service B: "+service2.getMessage());

	}

}
