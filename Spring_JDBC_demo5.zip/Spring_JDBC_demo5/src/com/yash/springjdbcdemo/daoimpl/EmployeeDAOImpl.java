package com.yash.springjdbcdemo.daoimpl;

import java.sql.PreparedStatement;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.yash.springjdbcdemo.dao.EmployeeDAO;
import com.yash.springjdbcdemo.model.Employee;

@Component
public class EmployeeDAOImpl implements EmployeeDAO {
	
	@Autowired
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	
	public DataSource getDataSource() {
		return dataSource;
	}

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate=new JdbcTemplate(dataSource);
	}

	@Override
	public void saveEmployee(Employee employee) {
		try {
			String sql = "INSERT INTO employee(name,contact) VALUES(?,?)";
			PreparedStatement pstmt = dataSource.getConnection().prepareStatement(sql);
			pstmt.setString(1, employee.getName());
			pstmt.setString(2, employee.getContact());
			pstmt.executeUpdate();

			// Close the Prepared Statement
			pstmt.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public int getTotalEmployees() {
		return jdbcTemplate.queryForInt("SELECT count(*) FROM employees");
	}
}