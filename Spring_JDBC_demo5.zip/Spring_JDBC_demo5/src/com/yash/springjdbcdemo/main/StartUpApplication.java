package com.yash.springjdbcdemo.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.springjdbcdemo.dao.EmployeeDAO;

public class StartUpApplication {

	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		EmployeeDAO dao = applicationContext.getBean("employeeDAOImpl", EmployeeDAO.class);
		int totalEmployees = dao.getTotalEmployees();
		System.out.println("Total Employees - "+totalEmployees);
	}
	
}
