package com.yash.mvc.controller;


import java.text.SimpleDateFormat;
import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.yash.mvc.model.User;

@Controller
@RequestMapping("/users")
public class UserController {
	@InitBinder
	public void initBinder(WebDataBinder webDataBinder) {
		webDataBinder.setDisallowedFields(new String[] {"contact"});
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy**mm**dd");
		webDataBinder.registerCustomEditor(Date.class, "joiningDate", new CustomDateEditor(dateFormat, true));
	}
	
	//You will use this method to avoid mentioning model.addAttribute() in every method
	@ModelAttribute
	public void commonHeader(Model model) {
		model.addAttribute("msg", "Welcome to Spring World");
	}
	
	@RequestMapping(value="/showForm",method=RequestMethod.GET)
	public String showRegistrationForm() {
		return "showRegistrationForm";
	}
//	@RequestMapping(value="/showForm",method=RequestMethod.GET)
//	public String showRegistrationForm(Model model) {
//		model.addAttribute("msg", "Welcome to Spring World");
//		return "showRegistrationForm";
//	}

	@RequestMapping(value="/processUserRegistration", method=RequestMethod.POST)
	public String processUserRegstration(@Valid @ModelAttribute("user")User user, BindingResult result ) { 
		if(result.hasErrors()) {
			return "showRegistrationForm";
		}
		return "welcome";
	}
//	@RequestMapping(value="/processUserRegistration", method=RequestMethod.POST)
//	public String processUserRegstration(@ModelAttribute("user")User user, Model model) {
//		model.addAttribute("msg", "Welcome to Spring World");
//		return "welcome";
//	}
	
	
	
}
